module SomeModule(g, h) where

f = head

g = f [f]

h = f