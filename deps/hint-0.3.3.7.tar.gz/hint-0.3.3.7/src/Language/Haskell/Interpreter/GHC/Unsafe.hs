-----------------------------------------------------------------------------
-- |
-- DEPRECATED: use @Language.Haskell.Interpreter.Unsafe@ instead.
-----------------------------------------------------------------------------
module Language.Haskell.Interpreter.GHC.Unsafe
{-# DEPRECATED "Import Language.Haskell.Interpreter.Unsafe instead." #-}
(
    module Language.Haskell.Interpreter.Unsafe
)

where

import Language.Haskell.Interpreter.Unsafe
