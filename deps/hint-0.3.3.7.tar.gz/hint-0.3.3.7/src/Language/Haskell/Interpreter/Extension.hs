module Language.Haskell.Interpreter.Extension ( module Hint.Extension )

where

import Hint.Extension
