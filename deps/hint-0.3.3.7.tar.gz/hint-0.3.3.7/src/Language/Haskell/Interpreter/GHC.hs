-----------------------------------------------------------------------------
-- |
-- DEPRECATED: use @Language.Haskell.Interpreter.Unsafe@ instead.
-----------------------------------------------------------------------------
module Language.Haskell.Interpreter.GHC
{-# DEPRECATED "Import Language.Haskell.Interpreter instead." #-}
(
    module Language.Haskell.Interpreter
)

where

import Language.Haskell.Interpreter
