# The vector package

An efficient implementation of Int-indexed arrays (both mutable and
immutable), with a powerful loop optimisation framework.
